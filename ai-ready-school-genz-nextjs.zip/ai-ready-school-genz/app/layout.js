import "./globals.css";

export const metadata = {
  title: "AI Ready School — Bring AI Into Your School Without Complexity",
  description:
    "A complete AI ecosystem for schools. Empower teachers, personalize learning, and future-proof your institution.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
