import Navbar from "../components/Navbar";
import Hero from "../components/Hero";
import TrustedBy from "../components/TrustedBy";
import Products from "../components/Products";
import Stats from "../components/Stats";
import Testimonials from "../components/Testimonials";
import Features from "../components/Features";
import FinalCTA from "../components/FinalCTA";
import Footer from "../components/Footer";

export default function Home() {
  return (
    <main>
      <Navbar />
      <Hero />
      <TrustedBy />
      <Products />
      <Stats />
      <Testimonials />
      <Features />
      <FinalCTA />
      <Footer />
    </main>
  );
}
