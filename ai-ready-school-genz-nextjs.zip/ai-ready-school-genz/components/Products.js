"use client";

import { Brain, GraduationCap, Layers, Rocket, Server, ArrowRight } from "lucide-react";
import AnimatedSection from "./AnimatedSection";

const products = [
  {
    name: "Cypher",
    tag: "For Students",
    desc: "An AI-powered learning companion that personalizes study paths, answers questions in real-time, and adapts to every student's pace and style.",
    icon: Brain,
    color: "#3B82F6",
    bg: "rgba(59,130,246,0.08)",
  },
  {
    name: "Morpheus",
    tag: "For Teachers",
    desc: "AI teaching assistant that automates lesson planning, generates assessments, provides analytics, and frees up educators to focus on what matters.",
    icon: GraduationCap,
    color: "#8B5CF6",
    bg: "rgba(139,92,246,0.08)",
  },
  {
    name: "Zion",
    tag: "AI Toolkit",
    desc: "A curated suite of AI-powered tools — from content generation to smart grading — designed specifically for the education workflow.",
    icon: Layers,
    color: "#0EA5E9",
    bg: "rgba(14,165,233,0.08)",
  },
  {
    name: "NEO",
    tag: "Innovation Lab",
    desc: "A sandbox environment where students and teachers explore, build, and experiment with AI projects in a safe, guided setting.",
    icon: Rocket,
    color: "#F59E0B",
    bg: "rgba(245,158,11,0.08)",
  },
  {
    name: "Matrix",
    tag: "Infrastructure",
    desc: "The secure AI backbone that powers everything — handling data privacy, integrations, admin controls, and seamless deployment across your school.",
    icon: Server,
    color: "#10B981",
    bg: "rgba(16,185,129,0.08)",
  },
];

export default function Products() {
  return (
    <section className="py-28 px-6 relative">
      <div className="max-w-[1200px] mx-auto">
        <AnimatedSection>
          <div className="text-center mb-[72px]">
            <div className="section-tag bg-purple/10 text-purple mx-auto mb-5">
              Platform
            </div>
            <h2 className="font-heading text-[clamp(30px,4vw,46px)] font-extrabold tracking-[-0.035em] leading-[1.15] mb-4">
              One Platform.
              <br />
              Five Powerful AI Systems.
            </h2>
            <p className="text-lg text-slate-500 max-w-[560px] mx-auto leading-relaxed">
              Everything your school needs to adopt AI — from student learning to
              backend infrastructure — unified in one ecosystem.
            </p>
          </div>
        </AnimatedSection>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {products.map((p, i) => {
            const Icon = p.icon;
            return (
              <AnimatedSection key={p.name} delay={i * 0.08}>
                <div className="product-card h-full">
                  <div
                    className="w-14 h-14 rounded-2xl flex items-center justify-center mb-6"
                    style={{ background: p.bg, color: p.color }}
                  >
                    <Icon size={28} strokeWidth={1.5} />
                  </div>
                  <div className="flex items-center gap-2.5 mb-3">
                    <h3 className="font-heading text-[22px] font-bold tracking-tight">
                      {p.name}
                    </h3>
                    <span
                      className="text-[11.5px] font-semibold px-2.5 py-0.5 rounded-full"
                      style={{ color: p.color, background: p.bg }}
                    >
                      {p.tag}
                    </span>
                  </div>
                  <p className="text-[15px] leading-relaxed text-slate-500">
                    {p.desc}
                  </p>
                  <div
                    className="mt-6 flex items-center gap-1.5 text-sm font-semibold cursor-pointer"
                    style={{ color: p.color }}
                  >
                    Learn more <ArrowRight size={16} />
                  </div>
                </div>
              </AnimatedSection>
            );
          })}
        </div>
      </div>
    </section>
  );
}
