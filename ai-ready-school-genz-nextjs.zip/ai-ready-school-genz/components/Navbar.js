"use client";

import { useState, useEffect } from "react";
import { ChevronDown, Menu, X } from "lucide-react";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled
          ? "py-3 bg-surface/90 backdrop-blur-xl border-b border-black/5"
          : "py-5 bg-transparent border-b border-transparent"
      }`}
    >
      <div className="max-w-[1200px] mx-auto px-6 flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="flex items-center">
          <img src="/logo.png" alt="AI Ready School" className="h-11 object-contain" style={{ mixBlendMode: "screen" }} />
        </a>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center gap-9">
          <span className="nav-link">
            Products <ChevronDown size={14} />
          </span>
          <span className="nav-link">Solutions</span>
          <span className="nav-link">About</span>
          <span className="nav-link">Blog</span>
        </div>

        {/* CTA */}
        <div className="flex items-center gap-3">
          <span className="nav-link hidden md:flex">Login</span>
          <button className="btn-primary !py-2.5 !px-6 !text-sm !rounded-xl">
            Book Demo
          </button>
          <button
            className="md:hidden text-primary"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="absolute top-full inset-x-0 bg-surface/98 backdrop-blur-xl border-b border-slate-200 p-6 flex flex-col gap-5 md:hidden">
          <span className="nav-link">Products</span>
          <span className="nav-link">Solutions</span>
          <span className="nav-link">About</span>
          <span className="nav-link">Blog</span>
          <span className="nav-link">Login</span>
          <button className="btn-primary justify-center">Book Demo</button>
        </div>
      )}
    </nav>
  );
}
