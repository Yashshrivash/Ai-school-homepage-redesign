"use client";

import { ArrowRight } from "lucide-react";
import AnimatedSection from "./AnimatedSection";

export default function Hero() {
  return (
    <section className="relative pt-40 pb-24 overflow-hidden">
      {/* Background effects */}
      <div className="absolute -top-[200px] -right-[200px] w-[700px] h-[700px] rounded-full bg-[radial-gradient(circle,rgba(59,130,246,0.08)_0%,rgba(139,92,246,0.04)_50%,transparent_70%)] pointer-events-none" />
      <div className="absolute -bottom-[300px] -left-[200px] w-[600px] h-[600px] rounded-full bg-[radial-gradient(circle,rgba(139,92,246,0.06)_0%,transparent_70%)] pointer-events-none" />
      <div className="grid-bg" />

      <div className="max-w-[1200px] mx-auto px-6 relative z-10">
        <AnimatedSection>
          <div className="text-center max-w-[780px] mx-auto">
            <div className="section-tag bg-accent/10 text-accent mx-auto mb-6">
              <span className="w-1.5 h-1.5 rounded-full bg-accent inline-block" />
              Trusted by 100+ Schools Across India
            </div>

            <h1 className="font-heading text-[clamp(36px,5.5vw,64px)] font-extrabold leading-[1.08] tracking-[-0.04em] mb-6 bg-gradient-to-br from-primary via-blue-800 to-indigo-500 bg-clip-text text-transparent">
              Bring AI Into Your School — Without Complexity
            </h1>

            <p className="text-[clamp(17px,2vw,20px)] leading-relaxed text-slate-500 max-w-[580px] mx-auto mb-10">
              A complete AI ecosystem built for schools. Empower teachers,
              personalize learning, and future-proof your institution — all from
              one platform.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="btn-primary !py-4 !px-9 !text-base">
                Book a Free Demo <ArrowRight size={18} />
              </button>
              <button className="btn-secondary !py-4 !px-9 !text-base">
                Explore Products
              </button>
            </div>
          </div>
        </AnimatedSection>

        {/* Dashboard Mockup */}
        <AnimatedSection delay={0.2}>
          <div className="mt-[72px] max-w-[960px] mx-auto rounded-2xl overflow-hidden bg-gradient-to-br from-primary to-[#1E3A5F] p-8 pb-0 shadow-[0_40px_80px_rgba(11,31,58,0.2)]">
            <div className="flex gap-2 mb-6">
              <div className="w-3 h-3 rounded-full bg-[#FF5F57]" />
              <div className="w-3 h-3 rounded-full bg-[#FFBD2E]" />
              <div className="w-3 h-3 rounded-full bg-[#27C93F]" />
            </div>
            <div className="bg-gradient-to-b from-slate-50 to-indigo-50 rounded-t-2xl p-8 min-h-[320px]">
              <div className="flex flex-wrap gap-3 mb-6">
                {["Student Activity", "Teacher Insights", "AI Usage", "Reports"].map(
                  (tab, i) => (
                    <span
                      key={tab}
                      className={`px-5 py-2 rounded-[10px] text-[13px] font-semibold ${
                        i === 0
                          ? "bg-gradient-to-r from-accent to-indigo-500 text-white"
                          : "bg-slate-200 text-slate-500"
                      }`}
                    >
                      {tab}
                    </span>
                  )
                )}
              </div>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: "Active Students", val: "4,832", change: "+12%" },
                  { label: "AI Queries Today", val: "18,291", change: "+28%" },
                  { label: "Lessons Created", val: "342", change: "+8%" },
                  { label: "Avg Engagement", val: "94%", change: "+5%" },
                ].map((s) => (
                  <div
                    key={s.label}
                    className="bg-white rounded-xl p-5 border border-slate-200"
                  >
                    <div className="text-xs text-slate-400 font-medium mb-2">
                      {s.label}
                    </div>
                    <div className="font-heading text-2xl font-bold text-primary">
                      {s.val}
                    </div>
                    <div className="text-xs text-emerald-500 font-semibold mt-1">
                      {s.change}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </section>
  );
}
