"use client";

import { ArrowRight } from "lucide-react";
import AnimatedSection from "./AnimatedSection";

export default function FinalCTA() {
  return (
    <section className="py-28 px-6">
      <AnimatedSection>
        <div className="max-w-[960px] mx-auto rounded-3xl bg-gradient-to-br from-primary via-[#1E3A5F] to-[#2E1065] p-[clamp(48px,6vw,80px)] text-center relative overflow-hidden">
          {/* Decorative blobs */}
          <div className="absolute -top-20 -right-20 w-72 h-72 rounded-full bg-[radial-gradient(circle,rgba(59,130,246,0.2),transparent_70%)]" />
          <div className="absolute -bottom-20 -left-20 w-72 h-72 rounded-full bg-[radial-gradient(circle,rgba(139,92,246,0.15),transparent_70%)]" />

          <div className="relative z-10">
            <h2 className="font-heading text-[clamp(28px,4vw,44px)] font-extrabold text-white tracking-[-0.035em] leading-[1.15] mb-5">
              Start Your AI Journey Today
            </h2>
            <p className="text-[clamp(16px,2vw,19px)] text-white/60 max-w-[500px] mx-auto mb-9 leading-relaxed">
              Join 100+ forward-thinking schools already transforming education
              with AI. Book a free demo and see the platform in action.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="btn-primary !bg-white !text-primary !shadow-[0_4px_24px_rgba(0,0,0,0.2)] !py-4 !px-10 !text-base !rounded-2xl">
                Book a Free Demo <ArrowRight size={18} />
              </button>
              <button className="inline-flex items-center gap-2 py-4 px-9 bg-white/10 text-white border border-white/15 rounded-2xl text-base font-semibold cursor-pointer transition-all hover:bg-white/20">
                Contact Sales
              </button>
            </div>
          </div>
        </div>
      </AnimatedSection>
    </section>
  );
}
