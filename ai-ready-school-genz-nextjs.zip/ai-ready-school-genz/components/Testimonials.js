"use client";

import { Star } from "lucide-react";
import AnimatedSection from "./AnimatedSection";

const testimonials = [
  {
    quote:
      "AI Ready School transformed how our teachers plan and deliver lessons. The impact on student engagement has been remarkable.",
    name: "Dr. Meera Sharma",
    role: "Principal, Delhi Public School",
    color: "#3B82F6",
  },
  {
    quote:
      "We evaluated five platforms. AI Ready School was the only one that understood our needs as educators, not just technologists.",
    name: "Rajesh Iyer",
    role: "Academic Head, Vidya Academy",
    color: "#8B5CF6",
  },
  {
    quote:
      "The implementation was seamless. Within weeks, both teachers and students were actively using the AI tools daily.",
    name: "Priya Nair",
    role: "Director, Greenfield International",
    color: "#0EA5E9",
  },
];

export default function Testimonials() {
  return (
    <section className="py-28 px-6">
      <div className="max-w-[1200px] mx-auto">
        <AnimatedSection>
          <div className="text-center mb-16">
            <div className="section-tag bg-accent/10 text-accent mx-auto mb-5">
              Testimonials
            </div>
            <h2 className="font-heading text-[clamp(30px,4vw,46px)] font-extrabold tracking-[-0.035em] leading-[1.15] mb-4">
              Hear From School Leaders
            </h2>
            <p className="text-lg text-slate-500 max-w-[480px] mx-auto leading-relaxed">
              Principals and academic heads share their experience with AI Ready
              School.
            </p>
          </div>
        </AnimatedSection>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-[1080px] mx-auto">
          {testimonials.map((t, i) => (
            <AnimatedSection key={i} delay={i * 0.1}>
              <div className="testimonial-card h-full flex flex-col">
                {/* Quote icon */}
                <svg
                  width="32"
                  height="32"
                  viewBox="0 0 24 24"
                  fill={t.color}
                  opacity={0.15}
                  className="mb-4"
                >
                  <path d="M3 21c3 0 7-1 7-8V5c0-1.25-.756-2.017-2-2H4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2 1 0 1 0 1 1v1c0 1-1 2-2 2s-1 .008-1 1.031V20c0 1 0 1 1 1z" />
                  <path d="M15 21c3 0 7-1 7-8V5c0-1.25-.757-2.017-2-2h-4c-1.25 0-2 .75-2 1.972V11c0 1.25.75 2 2 2h.75c0 2.25.25 4-2.75 4v3c0 1 0 1 1 1z" />
                </svg>

                <p className="text-base leading-relaxed text-slate-700 mb-6 italic flex-grow">
                  &ldquo;{t.quote}&rdquo;
                </p>

                <div className="flex gap-1 mb-4">
                  {Array.from({ length: 5 }).map((_, j) => (
                    <Star
                      key={j}
                      size={14}
                      fill="#F59E0B"
                      stroke="none"
                    />
                  ))}
                </div>

                <div className="flex items-center gap-3.5">
                  <div
                    className="w-11 h-11 rounded-xl flex items-center justify-center font-bold text-base"
                    style={{
                      background: `${t.color}18`,
                      color: t.color,
                    }}
                  >
                    {t.name[0]}
                  </div>
                  <div>
                    <div className="font-semibold text-[15px] text-primary">
                      {t.name}
                    </div>
                    <div className="text-[13px] text-slate-400">{t.role}</div>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}
