"use client";

import AnimatedSection from "./AnimatedSection";

const schools = [
  { name: "Delhi Public School", loc: "New Delhi", emoji: "🏫" },
  { name: "Sunrise Academy", loc: "Bengaluru", emoji: "🌅" },
  { name: "Greenfield Intl", loc: "Chennai", emoji: "🌿" },
  { name: "Vidya Academy", loc: "Mumbai", emoji: "📖" },
  { name: "Oakridge School", loc: "Hyderabad", emoji: "🌳" },
  { name: "Ryan International", loc: "Pune", emoji: "🎓" },
  { name: "Kendriya Vidyalaya", loc: "Pan India", emoji: "🇮🇳" },
  { name: "Amity International", loc: "Noida", emoji: "⭐" },
];

export default function TrustedBy() {
  return (
    <section className="py-16 px-6 relative overflow-hidden">
      <div className="max-w-[1240px] mx-auto">
        <AnimatedSection>
          <div className="flex items-center justify-center gap-4 mb-10 flex-wrap">
            <div
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full"
              style={{
                background:
                  "linear-gradient(135deg, rgba(168,85,247,0.12), rgba(59,130,246,0.12))",
                border: "1px solid rgba(168,85,247,0.15)",
              }}
            >
              <span className="syne text-xl font-extrabold text-[#c084fc]">
                100+
              </span>
              <span className="text-[13px] font-semibold text-[#a1a1aa]">
                Schools
              </span>
            </div>
            <h3
              className="syne text-[clamp(20px,3vw,28px)] font-bold text-[#52525b] text-center"
              style={{ letterSpacing: "-0.03em" }}
            >
              Trusted by leading institutions across India
            </h3>
          </div>
        </AnimatedSection>

        <AnimatedSection delay={0.1}>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-[900px] mx-auto">
            {schools.map((school, i) => (
              <div
                key={i}
                className="py-5 px-4 rounded-2xl text-center transition-all duration-300 cursor-default group"
                style={{
                  background: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(255,255,255,0.05)",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background =
                    "rgba(168,85,247,0.06)";
                  e.currentTarget.style.borderColor =
                    "rgba(168,85,247,0.15)";
                  e.currentTarget.style.transform = "translateY(-3px)";
                  e.currentTarget.style.boxShadow =
                    "0 12px 32px rgba(168,85,247,0.08)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background =
                    "rgba(255,255,255,0.02)";
                  e.currentTarget.style.borderColor =
                    "rgba(255,255,255,0.05)";
                  e.currentTarget.style.transform = "translateY(0)";
                  e.currentTarget.style.boxShadow = "none";
                }}
              >
                <div className="text-2xl mb-2">{school.emoji}</div>
                <div className="text-[13px] font-bold text-[#e4e4e7] mb-0.5">
                  {school.name}
                </div>
                <div className="text-[11px] text-[#52525b] font-medium">
                  {school.loc}
                </div>
              </div>
            ))}
          </div>
        </AnimatedSection>
      </div>
    </section>
  );
}
