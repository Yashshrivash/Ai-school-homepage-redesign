export default function Footer() {
  const columns = [
    { title: "Products", links: ["Cypher", "Morpheus", "Zion", "NEO", "Matrix"] },
    { title: "Company", links: ["About", "Blog", "Careers", "Contact"] },
    { title: "Resources", links: ["Documentation", "Help Center", "Privacy", "Terms"] },
  ];

  return (
    <footer className="border-t border-[#F0F1F4] pt-16 pb-10 px-6 bg-white">
      <div className="max-w-[1200px] mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center mb-4">
              <img src="/logo.png" alt="AI Ready School" className="h-10 object-contain" style={{ mixBlendMode: "screen" }} />
            </div>
            <p className="text-sm text-slate-400 leading-relaxed max-w-[260px]">
              Making every school AI-ready with tools built for educators, by
              educators.
            </p>
          </div>

          {/* Links */}
          {columns.map((col) => (
            <div key={col.title}>
              <h4 className="text-[13px] font-bold text-primary mb-4 uppercase tracking-wider">
                {col.title}
              </h4>
              {col.links.map((link) => (
                <a
                  key={link}
                  href="#"
                  className="block text-sm text-slate-400 mb-2.5 hover:text-accent transition-colors"
                >
                  {link}
                </a>
              ))}
            </div>
          ))}
        </div>

        <div className="border-t border-[#F0F1F4] pt-6 flex flex-wrap justify-between gap-3">
          <span className="text-[13px] text-slate-300">
            © 2026 AI Ready School. All rights reserved.
          </span>
          <span className="text-[13px] text-slate-300">
            Made with ❤️ for Education
          </span>
        </div>
      </div>
    </footer>
  );
}
