"use client";

import AnimatedSection from "./AnimatedSection";

const stats = [
  { value: "100+", label: "Schools Trust Us" },
  { value: "50,000+", label: "Students Learning" },
  { value: "3,200+", label: "Teachers Empowered" },
  { value: "98%", label: "Satisfaction Rate" },
];

export default function Stats() {
  return (
    <section className="py-20 px-6 bg-gradient-to-b from-blue-50/60 to-surface">
      <div className="max-w-[960px] mx-auto grid grid-cols-2 lg:grid-cols-4 gap-5">
        {stats.map((s, i) => (
          <AnimatedSection key={s.label} delay={i * 0.08}>
            <div className="stat-card">
              <div className="font-heading text-[clamp(28px,3.5vw,40px)] font-extrabold tracking-tight bg-gradient-to-br from-accent to-purple bg-clip-text text-transparent mb-1">
                {s.value}
              </div>
              <div className="text-sm text-slate-500 font-medium">{s.label}</div>
            </div>
          </AnimatedSection>
        ))}
      </div>
    </section>
  );
}
