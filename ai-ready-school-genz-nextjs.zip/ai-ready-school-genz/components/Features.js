"use client";

import { Check } from "lucide-react";
import AnimatedSection from "./AnimatedSection";

const features = [
  "Designed specifically for K-12 schools",
  "No technical setup required",
  "FERPA and data privacy compliant",
  "Dedicated onboarding support",
  "Works with your existing LMS",
  "Continuous AI model updates",
  "Custom training for teachers",
  "Enterprise-grade security",
  "Real-time analytics dashboard",
];

export default function Features() {
  return (
    <section className="py-24 px-6 bg-white">
      <div className="max-w-[1080px] mx-auto">
        <AnimatedSection>
          <div className="text-center mb-14">
            <h2 className="font-heading text-[clamp(28px,3.5vw,40px)] font-extrabold tracking-[-0.035em] leading-[1.15] mb-4">
              Why Schools Choose Us
            </h2>
            <p className="text-[17px] text-slate-500 max-w-[500px] mx-auto leading-relaxed">
              Built for education, not retrofitted from enterprise software.
            </p>
          </div>
        </AnimatedSection>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {features.map((f, i) => (
            <AnimatedSection key={f} delay={i * 0.04}>
              <div className="flex items-center gap-3.5 py-4 px-5 rounded-xl bg-slate-50 border border-[#F0F1F4]">
                <div className="w-7 h-7 rounded-lg flex-shrink-0 bg-gradient-to-br from-accent/10 to-purple/10 flex items-center justify-center text-accent">
                  <Check size={16} strokeWidth={2.5} />
                </div>
                <span className="text-[14.5px] font-medium text-slate-700">
                  {f}
                </span>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}
